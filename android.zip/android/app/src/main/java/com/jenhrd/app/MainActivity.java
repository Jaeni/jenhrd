package com.jenhrd.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
